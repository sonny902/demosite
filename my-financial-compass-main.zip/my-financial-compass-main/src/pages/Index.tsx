import { DollarSign, TrendingUp, CreditCard, PiggyBank, Bell, Search } from "lucide-react";
import StatCard from "@/components/StatCard";
import SpendingChart from "@/components/SpendingChart";
import TransactionList from "@/components/TransactionList";
import AllocationChart from "@/components/AllocationChart";

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <DollarSign className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-lg font-semibold text-foreground tracking-tight">Vault</span>
          </div>
          <div className="flex items-center gap-3">
            <button className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center hover:bg-accent/80 transition-colors">
              <Search className="h-4 w-4 text-muted-foreground" />
            </button>
            <button className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center hover:bg-accent/80 transition-colors relative">
              <Bell className="h-4 w-4 text-muted-foreground" />
              <span className="absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-primary border-2 border-card" />
            </button>
            <div className="h-9 w-9 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium text-primary">
              JD
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8 space-y-6">
        {/* Welcome */}
        <div>
          <h1 className="text-2xl font-semibold text-foreground tracking-tight"><h1 className="text-2xl font-semibold text-foreground tracking-tight">Good morning, Macsen</h1></h1>
          <p className="text-sm text-muted-foreground mt-1">Here's your financial overview for today.</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Total Balance" value="$48,562.80" change="+12.5% from last month" changeType="gain" icon={DollarSign} />
          <StatCard title="Monthly Income" value="$9,650.00" change="+8.2% from last month" changeType="gain" icon={TrendingUp} />
          <StatCard title="Monthly Expenses" value="$4,218.32" change="-3.1% from last month" changeType="gain" icon={CreditCard} />
          <StatCard title="Savings Rate" value="56.3%" change="+4.7% from last month" changeType="gain" icon={PiggyBank} />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <SpendingChart />
          </div>
          <AllocationChart />
        </div>

        {/* Transactions */}
        <TransactionList />
      </main>
    </div>
  );
};

export default Index;
