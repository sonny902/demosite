import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

const data = [
  { name: "Stocks", value: 45, color: "hsl(160, 60%, 45%)" },
  { name: "Real Estate", value: 25, color: "hsl(200, 70%, 55%)" },
  { name: "Crypto", value: 15, color: "hsl(260, 60%, 60%)" },
  { name: "Bonds", value: 10, color: "hsl(38, 92%, 50%)" },
  { name: "Cash", value: 5, color: "hsl(340, 65%, 55%)" },
];

const AllocationChart = () => {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="text-sm font-medium text-card-foreground mb-4">Portfolio Allocation</h3>
      <div className="flex items-center gap-6">
        <div className="w-36 h-36 flex-shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={40}
                outerRadius={65}
                paddingAngle={3}
                dataKey="value"
                strokeWidth={0}
              >
                {data.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="space-y-2.5 flex-1">
          {data.map((item) => (
            <div key={item.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-muted-foreground">{item.name}</span>
              </div>
              <span className="text-xs font-mono font-medium text-card-foreground">{item.value}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AllocationChart;
