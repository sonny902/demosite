import { ArrowDownLeft, ArrowUpRight, ShoppingCart, Home, Zap, Coffee, Briefcase } from "lucide-react";

const transactions = [
  { id: 1, name: "Salary Deposit", category: "Income", amount: "+$8,450.00", type: "gain" as const, icon: Briefcase, date: "Mar 25" },
  { id: 2, name: "Rent Payment", category: "Housing", amount: "-$2,100.00", type: "loss" as const, icon: Home, date: "Mar 24" },
  { id: 3, name: "Grocery Store", category: "Shopping", amount: "-$156.32", type: "loss" as const, icon: ShoppingCart, date: "Mar 23" },
  { id: 4, name: "Freelance Payment", category: "Income", amount: "+$1,200.00", type: "gain" as const, icon: Zap, date: "Mar 22" },
  { id: 5, name: "Coffee Shop", category: "Food", amount: "-$12.50", type: "loss" as const, icon: Coffee, date: "Mar 22" },
  { id: 6, name: "Investment Return", category: "Income", amount: "+$340.00", type: "gain" as const, icon: ArrowDownLeft, date: "Mar 21" },
];

const TransactionList = () => {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-card-foreground">Recent Transactions</h3>
        <button className="text-xs text-primary hover:underline">View all</button>
      </div>
      <div className="space-y-1">
        {transactions.map((tx) => (
          <div
            key={tx.id}
            className="flex items-center justify-between py-3 px-2 rounded-lg hover:bg-accent/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${tx.type === "gain" ? "bg-gain/10" : "bg-loss/10"}`}>
                <tx.icon className={`h-4 w-4 ${tx.type === "gain" ? "text-gain" : "text-loss"}`} />
              </div>
              <div>
                <p className="text-sm font-medium text-card-foreground">{tx.name}</p>
                <p className="text-xs text-muted-foreground">{tx.category} · {tx.date}</p>
              </div>
            </div>
            <span className={`text-sm font-mono font-medium ${tx.type === "gain" ? "text-gain" : "text-loss"}`}>
              {tx.amount}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TransactionList;
