import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string;
  change: string;
  changeType: "gain" | "loss" | "neutral";
  icon: LucideIcon;
}

const StatCard = ({ title, value, change, changeType, icon: Icon }: StatCardProps) => {
  const changeColor =
    changeType === "gain"
      ? "text-gain"
      : changeType === "loss"
      ? "text-loss"
      : "text-muted-foreground";

  return (
    <div className="rounded-xl border border-border bg-card p-5 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{title}</span>
        <div className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center">
          <Icon className="h-4 w-4 text-primary" />
        </div>
      </div>
      <div>
        <p className="text-2xl font-semibold font-mono tracking-tight text-card-foreground">{value}</p>
        <p className={`text-xs font-medium mt-1 ${changeColor}`}>{change}</p>
      </div>
    </div>
  );
};

export default StatCard;
